import { registerUser } from "../../services/service";
import { otpVerify } from "../../services/service";

export const REGISTER = "REGISTER";
export const OTP = "OTP";

export function register(register) {
  return dispatch =>
  registerUser(register).then((response) => { console.log("In action ", response)
      if (response) { debugger;
        return dispatch({
          type: REGISTER,
          payload: response
        });
      }
    });
}

export function otp(otp) {
  return dispatch =>
  otpVerify(otp).then((response) => { console.log("In action ", response)
      if (response) {
        return dispatch({
          type: OTP,
          payload: response
        });
      }
    });
}