import { REGISTER, OTP } from "../actions/register.action";
const initialState = {
  registerdata: "",
  otpdata: ""
};


const register = function(state = initialState, action) {
    switch (action.type) {
      case REGISTER: { console.log("action :", action.payload)
        return {
          ...state,
          registerdata: action.payload
        };
      }
      case OTP: { console.log("action :", action.payload)
        return {
          ...state,
          otpdata: action.payload
        };
      }
      default: {
        return state;
      }
    }
  };


  export default register;