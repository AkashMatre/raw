import { combineReducers } from "redux";

import login from "./login.reducer";
import register from "./register.reducer";
import contact from "./contactUs.reducer";
import customerEnquiryReducer from './../../components/admin/enquiry/enqueryReducer';
import customerBillDetailsReducer from './../../components/admin/reports/reportsReducer';

const appReducer = combineReducers({ login, register, contact, customerEnquiryReducer, customerBillDetailsReducer });

export default appReducer;