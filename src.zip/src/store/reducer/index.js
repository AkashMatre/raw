import { combineReducers } from "redux";

import login from "./login.reducer";
import register from "./register.reducer";
import contact from "./contactUs.reducer";

const appReducer = combineReducers({ login , register , contact});

export default appReducer;