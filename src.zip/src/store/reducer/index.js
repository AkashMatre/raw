import { combineReducers } from "redux";

import login from "./login.reducer";
import register from "./register.reducer";
import contact from "./contactUs.reducer";
import customerEnquiryReducer from './../../components/admin/enquiry/enqueryReducer';
import customerBillDetailsReducer from './../../components/admin/reports/reportsReducer';
import maitananceDashboardReducer from './../../components/maintanance/dashboard/dashboardReducer';
import maitananceServiceReducer from './../../components/maintanance/service/serviceReducer';

const appReducer = combineReducers({ login, register, contact, customerEnquiryReducer, customerBillDetailsReducer, maitananceDashboardReducer, maitananceServiceReducer });

export default appReducer;