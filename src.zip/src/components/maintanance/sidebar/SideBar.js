import React from 'react';
import { NavItem, NavLink, Nav, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap';
import classNames from 'classnames';
import { Link } from 'react-router-dom';

const SideBar = props => (
  <div className='sidebar is-open'>

    <div className="side-menu">
      <Nav vertical className="list-unstyled pb-3">
        <NavItem>

          <NavLink tag={Link} to={'/maintanance'}>

            <i className="fa fa-dashboard" ></i>   Dashboard
            </NavLink>
        </NavItem>
        {/* <NavItem>

          <UncontrolledDropdown nav inNavbar>
            <DropdownToggle nav caret>
              <i class="fa fa-user-plus"></i> Register User
                  </DropdownToggle>
            <DropdownMenu right>
              <DropdownItem tag={Link} to={'/adduser'}>
                Add User
                    </DropdownItem>
              <DropdownItem>
                Manage User
                    </DropdownItem>
            </DropdownMenu>
          </UncontrolledDropdown>
          {/*   </NavLink>*/}
        {/* </NavItem>  */}
        <NavItem>
          <NavLink tag={Link} to={'/maintananceService'}>
            <i class=" fa fa-newspaper-o"></i> Service
            </NavLink>
        </NavItem>
        {/* <NavItem>
          <NavLink tag={Link} to={'/reports'}>
            <i class="fa fa-car"></i> Vehicle  Category
            </NavLink>
        </NavItem>
        <NavItem>
          <NavLink tag={Link} to={'/reports'}>
            <i class=" fa fa-area-chart"></i>  Reports
            </NavLink>
        </NavItem>
        <NavItem>
          <NavLink tag={Link} to={'/customerEnquery'}>
            <i class=" fa fa-envelope-open-o "></i> Customer Enquiry
            </NavLink>
        </NavItem> */}
      </Nav>
    </div>
  </div >
);


export default SideBar;
