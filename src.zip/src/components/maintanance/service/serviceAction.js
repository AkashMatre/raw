import * as actionTypes from "./serviceActionType";
import axios from "axios";

export function saveVehicleBillStatus(vehicleServiceData) {
    console.log("tracking id" , vehicleServiceData)
  var headers = {
    "Content-Type": "application/json",
    // "x-auth-token": sessionStorage.getItem("token")
  }; 
  return function(dispatch) {
    return axios
      .get(`http://localhost:3200/registerUser`, { vehicleServiceData })
      .then(res => {
        dispatch({
          type: actionTypes.UPDATE_VEHICLE_STATUS,
          payload: res.data.data
        });
      });
  };
}

export function getRoutinServiceList() {
var headers = {
  "Content-Type": "application/json",
  // "x-auth-token": sessionStorage.getItem("token")
}; 
return function(dispatch) {
  return axios
    .get(`http://localhost:3200/registerUser`)
    .then(res => {
      dispatch({
        type: actionTypes.GET_ROUTINESERVICE_LIST,
        payload: res.data.data
      });
    });
};
}
export function getLabourChargeList() {
  var headers = {
    "Content-Type": "application/json",
    // "x-auth-token": sessionStorage.getItem("token")
  }; 
  return function(dispatch) {
    return axios
      .get(`http://localhost:3200/registerUser`)
      .then(res => {
        dispatch({
          type: actionTypes.GET_LABOURCHARGE_LIST,
          payload: res.data.data
        });
      });
  };
  }
  export function getSparpartList() {
    var headers = {
      "Content-Type": "application/json",
      // "x-auth-token": sessionStorage.getItem("token")
    }; 
    return function(dispatch) {
      return axios
        .get(`http://localhost:3200/registerUser`)
        .then(res => {
          dispatch({
            type: actionTypes.GET_SPAREPARTS_LIST,
            payload: res.data.data
          });
        });
    };
    }