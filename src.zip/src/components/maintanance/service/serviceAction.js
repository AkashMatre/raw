import * as actionTypes from "./serviceActionType";
import axios from "axios";

export function saveVehicleStatus(vehicleServiceData) {
    console.log("tracking id" , vehicleServiceData)
  var headers = {
    "Content-Type": "application/json",
    // "x-auth-token": sessionStorage.getItem("token")
  }; 
  return function(dispatch) {
    return axios
      .get(`http://localhost:3200/registerUser`, { vehicleServiceData })
      .then(res => {
        dispatch({
          type: actionTypes.UPDATE_VEHICLE_STATUS,
          payload: res.data.data
        });
      });
  };
}