import React, { Component } from "react";
import { Card, CardBody, Button, Input } from "reactstrap";
// import "./Styled.css";
import * as action from './serviceAction';
import { connect } from "react-redux";
// import Header from "./../header/header";
// import Sidebar from "./../side-bar/sidebar";

import NavBar from '../navbar/NavBar';
import SideBar from '../sidebar/SideBar';


const routineservice = [{serviceName:"100cc" , value:399},{serviceName:"80cc" , value:199}];
const labourchrgsrvc = [{labourchrgname:"Health Inspection" , value:199},{labourchrgname  :"Health Inspection2" , value:499}];
const sparpartchrgs = [{sparpartchrgsname:"Health Inspection" , value:199},{sparpartchrgsname  :"Health Inspection3" , value:499}];

class maintananceService extends Component {

  constructor() {
    super();
    console.log("const", this.state.cost)
  }
  state = {
    cost: 0,
    total: 0,
    discount: 10,
    discountAmount: 0,

    routineServiceCharge: 0,
    labourCharges: 0,
    spareParts: 0,
    otherCharges: 0,

    radioButnChk: "",
    routinServic: "",
    labourChrge: "",
    sparpart: "",
    engnType: "",
    othrchrgtxt: ""

  };

  getRoutintype = (e) => {
    this.setState({ routinServic: e.target.options[e.target.selectedIndex].text })
      this.setState({ routineServiceCharge: e.target.value }, () => {
        this.totalCalculation();
      });
  }

  getLabourCharges = (e) => {
    this.setState({ labourChrge: e.target.options[e.target.selectedIndex].text })
      this.setState({ labourCharges: e.target.value }, () => {
        this.totalCalculation();
      });
  }

  getSparePart = (e) => {
    this.setState({ sparpart: e.target.options[e.target.selectedIndex].text })
 
      this.setState({ spareParts: e.target.value }, () => {
        this.totalCalculation();
      });
  }
  getEngineType = (e) => {
    this.setState({ engnType: e.target.value }, () => {
    });
  }
  getOtherCharge = (e) => {
    this.setState({ otherCharges: e.target.value }, () => {
      this.totalCalculation();
    });
  }
  totalCalculation = () => {
    console.log("routine charges: est", this.state.routineServiceCharge);
    console.log("labour charges", this.state.labourCharges);
    console.log("spare charges", this.state.spareParts);
    console.log("other charges", this.state.otherCharges);

    let sum = parseInt(this.state.routineServiceCharge) + parseInt(this.state.labourCharges) + parseInt(this.state.spareParts) + parseInt(this.state.otherCharges);
    console.log("sum:", sum);
    let discountamount = (sum * parseInt(this.state.discount)) / 100;
    console.log("discountamount:", discountamount);
    let total = sum - discountamount;
    console.log("total:", total);
    this.setState({ cost: sum })
    this.setState({ discountAmount: discountamount })
    this.setState({ total: total })
  }
  onRadiocheck = (e) => {
    this.setState({ radioButnChk: e.target.value })
  }

  saveVehicleBillStatus = () => {
    console.log(this.state)
    const { dispatch } = this.props;
    dispatch(action.saveVehicleBillStatus(this.state));
  }
  otherchargesGetText = (e) => {

    this.setState({ othrchrgtxt: e.target.value });

  }
  componentDidMount(){
    const { dispatch } = this.props;
    dispatch(action.getRoutinServiceList());
    dispatch(action.getLabourChargeList());
    dispatch(action.getSparpartList());
  }
  render() {
    // console.log(document.getElementById("serviceType").innerText)
    return (
      <div className="Login-block" >
        {/* <Header />
        <Sidebar /> */}
        <NavBar></NavBar>
        <SideBar />
        <div style={{ marginLeft: "30%" }}>
          <div>
            <input type="radio" name="serviceType" value="Bike Services" onChange={(e) => this.onRadiocheck(e)} />Bike Services
         <input type="radio" name="serviceType" value="Car Services" onChange={(e) => this.onRadiocheck(e)} />Car Services
        </div>
          <div>
            {/* Routine Service <select onChange={(e) => this.getRoutintype(e)}><option>Select</option><option>100cc</option></select><input type="text" id="serviceType" value={this.state.routineServiceCharge} disabled={true} /> */}
            
            Routine Service <select onChange={(e) => this.getRoutintype(e)}><option>Select</option>{routineservice.map((item,key) =>(<option value={item.value}>{item.serviceName}</option>))}</select><input type="text" id="serviceType" value={this.state.routineServiceCharge} disabled={true} />
          </div>
          <div>
          
          Labour charges <select onChange={(e) => this.getLabourCharges(e)}><option>Select</option>{labourchrgsrvc.map((item,key) =>(<option value={item.value}>{item.labourchrgname}</option>))}</select><input type="text" value={this.state.labourCharges} disabled={true} />
            {/* Labour charges <select onChange={(e) => this.getLabourCharges(e)}><option>Select</option><option>Health Inspection</option></select><input type="text" value={this.state.labourCharges} disabled={true} /> */}
          </div>
          <div>
          
            {/* Spare Part <select onChange={(e) => this.getSparePart(e)}><option>Select</option><option>Health Inspection</option></select><select onChange={(e) => this.getEngineType(e)}><option>Select</option><option>80cc</option></select><input type="text" value={this.state.spareParts} disabled={true} /> */}
      Spare Part <select onChange={(e) => this.getSparePart(e)}><option>Select</option>{sparpartchrgs.map((item,key)=>(<option value={item.value}>{item.sparpartchrgsname}</option>))}</select><select onChange={(e) => this.getEngineType(e)}><option>Select</option><option>80cc</option></select><input type="text" value={this.state.spareParts} disabled={true} />
          </div>
          <div>
            Other charges <input type="text" onChange={this.otherchargesGetText} /><input type="text" value={this.state.otherCharges} onChange={(e) => this.getOtherCharge(e)} />
          </div>
          <div>
            <div>Cost {this.state.cost}</div>
            <div>Discount <input type="text" value={"-" + this.state.discount} /><input type="text" value={"Rs -" + this.state.discountAmount} /></div>
          </div>
          <div>
            Total Rs {this.state.total}
          </div>
          <Button onClick={this.saveVehicleBillStatus}>Submit</Button>
        </div>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    //  routineservicelist: state.maitananceServiceReducer.routineservicelist || "",
    //  labourchargelist: state.maitananceServiceReducer.labourchargelist || "",
    //  sparepartlist: state.maitananceServiceReducer.sparepartlist || ""
  };
};


export default connect(mapStateToProps)(maintananceService);
