import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { Nav, NavItem,   Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem
     } from 'reactstrap';
import logo from '../../../assets/images/logo.svg';

class NavBar extends Component {

    constructor() {
        super();
        this.state = {}
    }
    render() {
        return ( 

            <div className="navBar">
                <Nav>
                    <NavItem style={{ marginLeft: "0.5%" }}>
                        <img src={logo} alt="logo" height="90" width="70"></img>
                    </NavItem>
                    <NavItem className="name">
                        <h2>VEHICLE SERVICING</h2>
                    </NavItem>
                    <Navbar color="" dark expand="md">
                    <NavbarToggler />
                    <Collapse navbar>
                        <Nav className="ml-auto" navbar>                           
                            <UncontrolledDropdown nav inNavbar>
                                <DropdownToggle nav caret>                                        
                                    Hello {` ` + localStorage.getItem("name")}
                            </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>                                                          
                                        My Profile
                            </DropdownItem>
                            <DropdownItem divider />
                                    <DropdownItem>
                                        Change Password
                            </DropdownItem>
                                    <DropdownItem divider />
                                    <DropdownItem>
                                        Logout
                            </DropdownItem>
                                </DropdownMenu>
                            </UncontrolledDropdown>                           
                        </Nav>
                    </Collapse>
                    </Navbar>
                    {/* <NavItem className="navItem">
                  <NavLink exact to="/" activeClassName="Admin__Link__Active" className="Admin__Link">BOOK NOW</NavLink><label className="nav_Seprator">|</label>
               </NavItem> */}
                  
                </Nav>
         
            </div>
            
        );
    }
}

export default NavBar;