import React, { Component } from "react";
import {
    Dropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem
} from "reactstrap";
import Logo from "../../../assets/images/logo.svg";
import "./Styled.css";
class Header extends Component {
    state = {};
    render() {
        return (
            <div className="side-bar">
                <nav className="side-bar-nav">
                    <ul>
                        <li>
                            <a href="#">DASHBOARD</a>
                        </li>
                        <li>
                            <a href="#">SERVICE</a>
                        </li>
                    </ul>
                </nav>
            </div>
        );
    }
}

export default Header;