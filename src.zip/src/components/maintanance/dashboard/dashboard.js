import React, { Component } from "react";
import { Card, CardBody, Button, Input } from "reactstrap";
// import "./Styled.css";
// import { connect } from "react-redux";
// import * as action from './dashboardAction';
// import Header from "./../header/header";
// import Sidebar from "./../side-bar/sidebar";
import NavBar from '../navbar/NavBar';
import SideBar from '../sidebar/SideBar';

const vehicledata = [
  {
    date: "08/30/2019",
    vehicleType: "Honda Activa",
    customerName: "Jeffrey Garcia1"
  },
  {
    date: "12/30/2019",
    vehicleType: "Bajaj Chetak",
    customerName: "Jeffrey Garcia2"
  },
  {
    date: "09/30/2019",
    vehicleType: "Pulsar",
    customerName: "Jeffrey Garcia"
  },
  {
    date: "10/30/2019",
    vehicleType: "Vespa",
    customerName: "Jeffrey Garcia3"
  },
  {
    date: "11/30/2019",
    vehicleType: "Avenger",
    customerName: "Jeffrey Garcia4"
  },
  {
    date: "12/30/2019",
    vehicleType: "Honda City",
    customerName: "Jeffrey Garcia5"
  }
];

class MaintananceDashboard extends Component {
  state = {
    ischecked: false
  };

  multipleVehicleinfo = [];

  saveVehicleStatus = () => {
    console.log(this.multipleVehicleinfo, "########");
    document.getElementById("chkall").checked = false;
    const { dispatch } = this.props;
    //  dispatch(action.saveVehicleStatus(this.multipleVehicleinfo));
  };

  handleAllCheckboxChange = (targetdata, vehicledata) => {
    this.multipleVehicleinfo = [];
    for (let i = 0; i <= vehicledata.length - 1; i++) {
      if (targetdata) {
        document.getElementById("chkbx" + i).checked = true;
        this.multipleVehicleinfo.push(vehicledata[i]);
      } else {
        document.getElementById("chkbx" + i).checked = false;
      }
    }
  };

  handleCheckboxChange = (e, item, index) => {
    if (e.target.checked) {
      this.multipleVehicleinfo.push(item);
    } else {
      document.getElementById("chkall").checked = false;
      for (let i = 0; i < this.multipleVehicleinfo.length; i++) {
        if (
          this.multipleVehicleinfo[i].customerName === item.customerName &&
          this.multipleVehicleinfo[i].vehicleType === item.vehicleType
        ) {
          this.multipleVehicleinfo.splice(i, 1);
        }
      }
    }
  };

  render() {
    return (
      <div className="dashboard-block">
        <NavBar></NavBar>
        <SideBar />
        {/* <Header /> */}
        <div className="main-block">
          {/* <Sidebar /> */}
          <div className="Login-block">
            {/* <div className="card"> */}
            <div>
              <table style={{ marginLeft: "30%" }}>
                <tr className="table-header">
                  <th>
                    <input
                      type="checkbox"
                      id="chkall"
                      onChange={e => {
                        this.handleAllCheckboxChange(
                          e.target.checked,
                          vehicledata
                        );
                      }}
                    />
                  </th>
                  <th>Date</th>
                  <th>Vehicle Type</th>
                  <th>Customer Name</th>
                  <th>Status</th>
                </tr>
                {vehicledata.map((items, key) => (
                  <tr>
                    <td>
                      <input
                        type="checkbox"
                        id={"chkbx" + key}
                        key={items.date}
                        ischecked={this.state.ischecked}
                        onChange={e => {
                          this.handleCheckboxChange(e, items, key);
                        }}
                      />
                    </td>
                    <td>{items.date}</td>
                    <td>{items.vehicleType}</td>
                    <td>{items.customerName}</td>
                    <td>
                      <select>
                        <option value="washing">Washing</option>
                        <option value="vehiclesrvicing">
                          Vehicle Servicing
                        </option>
                      </select>
                    </td>
                  </tr>
                ))}
                <tr>
                  <td colSpan="5">
                    <Button onClick={this.saveVehicleStatus} className="save">Save</Button>
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    // vehicleDetails: state.dashboardskillReducer.deleteinfo || ""
  };
};

export default MaintananceDashboard;
