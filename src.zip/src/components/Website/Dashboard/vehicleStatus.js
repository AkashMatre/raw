import React, { Component } from 'react';
import { Form, Row, Col, FormGroup, Button } from 'reactstrap';
import NavBar from "../NavBar/NavBar";
import vehicle from '../../../assets/images/vehicle.png';
class vehicleStatus extends Component {

    constructor() {
        super();
        this.state = {
            checkStatus:""
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    } 
    handleChange(e) {
        let target = e.target;
        let value = target.value;
        let name = target.name;

        this.setState({
            [name]: value
        });
    }
    handleSubmit(e) {
        e.preventDefault();
        this.props.history.push('/vehicleTrack');
    }

    render() {
        const style = {
            marginLeft: '2%'
        };
        return (
            <div className="">
                <NavBar></NavBar>
                <div className="mainDiv">
                  <div>
                       <h1 style={{textAlign:"center"}}>Add More Life To Your Vehicle</h1>
                   </div>
                    <div className="dashboard shadow-lg p-3 mb-5 bg-white rounded">
                        <div>
                            <Form  noValidate>
                                <Row>
                                    <Col lg={6}>
                                        <Row>
                                            <Col lg={6}>
                                                <FormGroup>
                                                    <input type="text" className="statusVehicle" id="checkStatus" placeholder="Enter Tracking Id" name="checkStatus" value={this.state.checkStatus} onChange={this.handleChange} required></input>
                                                </FormGroup>
                                            </Col>
                                            <Col lg={6}>
                                                <FormGroup>
                                                    <Button className="trackVehicle" onClick={this.handleSubmit}>CHECK STATUS</Button>
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <FormGroup>
                                            <label className="dash_Lable">OR</label><br/>
                                            <label className="call_lable">Call Us On 123456789</label>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={6}>
                                        <img src={vehicle} alt="vehicle" height="100%" width="100%" style={style}></img>
                                    </Col>
                                </Row>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default vehicleStatus;