import React, { Component } from 'react';
import { Form, Row, Col, FormGroup, Button } from 'reactstrap';
import NavBar from "../NavBar/NavBar";
import vehicle from '../../../assets/images/vehicle.png';
class vehicleStatus extends Component {

    constructor() {
        super();
        this.state = {
            checkStatus:""
        }

    } 
    render() {
        const style = {
            marginLeft: '2%'
        };
        return (
            <div className="">
                <NavBar></NavBar>
                <div className="mainDiv">
                  <div>
                       <h1 style={{textAlign:"center"}}>Add More Life To Your Vehicle</h1>
                   </div>
                    <div className="dashboard shadow-lg p-3 mb-5 bg-white rounded">
                        <div>
                            <Form  noValidate>
                                <Row>
                                    <Col lg={6}>
                                        <Row>
                                            <Col lg={6}>
                                                <FormGroup>
                                                    <input type="text" className="statusVehicle" id="checkStatus" placeholder="Enter Tracking Id" name="checkStatus" value={this.state.checkStatus} onChange={this.handleChange} required></input>
                                                </FormGroup>
                                            </Col>
                                            <Col lg={6}>
                                                <FormGroup>
                                                    <Button className="trackVehicle">CHECK STATUS</Button>
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <FormGroup>
                                            <label className="dash_Lable">OR</label><br/>
                                            <label className="call_lable">Call Us On 123456789</label>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={6}>
                                        <img src={vehicle} alt="vehicle" height="100%" width="100%" style={style}></img>
                                    </Col>
                                </Row>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default vehicleStatus;