import React, { Component } from 'react';
import { Form, Row, Col, FormGroup} from 'reactstrap';
import NavBar from "../NavBar/NavBar";

class vehicleTrack extends Component {

    constructor() {
        super();
    } 

    render() {
        return (
            <div className="">
                <NavBar></NavBar>
                <div className="mainDiv">
                   <div>
                       <h3>Vehicle Type : Honda Activa</h3>
                   </div>
                    <div className="dashboard shadow-lg p-3 mb-5 bg-white rounded">
                          <ul class="StepProgress">
                             <li class="StepProgress-item is-done"><strong>Vehicle Servicing in progress</strong></li>
                             <li class="StepProgress-item is-done"><strong>Vehicle Washing in progress</strong></li>
                             <li class="StepProgress-item current"><strong>Vehicle Washing Done</strong></li>
                             <li class="StepProgress-item"><strong>Vehicle Servicing Done</strong></li>
                          </ul>     
                    </div>
                </div>
            </div>
        );
    }
}

export default vehicleTrack;