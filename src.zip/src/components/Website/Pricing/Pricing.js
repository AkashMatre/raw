import React, { Component } from 'react';
import NavBar from "../NavBar/NavBar";
class Pricing extends Component {

    constructor() {
        super();
        this.state = { }
    }

    render() {
        return (
            <div>
                <NavBar></NavBar>
                <h3 style={{textAlign: "center",  marginTop:"2%", fontSize:"1.3em"}}>At Vehicle servicing we have devised a dedicated and systematically structured process which aims for a hassle free and eﬀortless customer experience.</h3>
                <h3 style={{textAlign: "center",  fontSize:"1.3em"}}>We constantly pursue to create cost-eﬃcient and eﬀective vehicle maintenance solution at your ﬁngertips.</h3>
            </div>
        );
    }
}

export default Pricing;