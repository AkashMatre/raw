import React, { Component } from 'react';
import { Form, Row, Col, FormGroup, Button , Alert} from 'reactstrap';
import '../Login/Login.css';
import NavBar from "../NavBar/NavBar";
import { contact } from "../../../store/actions/contactUs.action";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";
import connect from "react-redux/es/connect/connect";

class ContactUs extends Component {
    constructor() {
        super();
        this.state = {
            name: '',
            phoneNumber: '',
            emailId: '',
            message: '',
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e) {
        let target = e.target;
        let value = target.value;
        let name = target.name;

        this.setState({
            [name]: value
        });
    }

    handleSubmit(e) {
        e.preventDefault();
        var data = {
            name: this.state.name,
            phoneNumber: this.state.phoneNumber,
            email: this.state.emailId,
            message: this.state.message
        };
        this.props.contact(data);
    }

    componentWillReceiveProps = nextProps => {
        console.log("nextProps :", nextProps);
        if(nextProps.contactResp.contactdata.status===200){
            alert("Message sent successfully.")
            this.props.history.push('/');
        }
        else{
            document.getElementById("Warning").style.visibility = "visible";
        }
   };

    render() {
        return (

            <div>
                <NavBar></NavBar>

                <div className="contactUs">
                    <div>
                        <h1 style={{textAlign:"center"}}>Contact Us</h1>
                    </div>
                    <div className="register shadow-lg p-3 mb-5 bg-white rounded">
                        <div>
                            <Form onSubmit={this.handleSubmit} noValidate>
                                <Row>
                                    <Col lg={6}>
                                        <FormGroup>
                                            <label className="registerLable" htmlFor="name">Name</label>
                                            <input className="registerText" type="text" id="name" name="name" value={this.state.name} onChange={this.handleChange} required></input>
                                        </FormGroup>
                                        <FormGroup>
                                            <label className="registerLable" htmlFor="phoneNumber">Phone Number</label>
                                            <input className="registerText" type="text" id="phoneNumber" name="phoneNumber" value={this.state.phoneNumber} onChange={this.handleChange} required></input>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={6}>
                                        <FormGroup>
                                            <label className="registerLableTwo" htmlFor="emailId">Email</label>
                                            <input className="registerTextTwo" type="emailId" id="emailId" name="emailId" value={this.state.emailId} onChange={this.handleChange} required></input>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={12}>
                                        <FormGroup>
                                            <label className="msgLable" htmlFor="message">Message</label>
                                            <textarea className="msgText" type="text" id="message" name="message" value={this.state.message} onChange={this.handleChange} required></textarea>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={12}>
                                        <FormGroup>
                                            <Button className="msgButton">Send Message</Button>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={12}>
                                       <FormGroup>
                                            <Alert color="danger" id="Warning" className="warning" style={{ visibility: 'hidden', width: '100%',height: '100%'}}>
                                                Internal server error try again letter.
                                            </Alert>
                                        </FormGroup> 
                                    </Col>
                                </Row>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(
      {
        contact: contact
      },
      dispatch
    );
  }
  
  function mapStateToProps({ contact }) {
    return { contactResp: contact };
  }
  
  export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ContactUs));