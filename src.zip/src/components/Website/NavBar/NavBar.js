import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { Nav, NavItem } from 'reactstrap';
import logo from '../../../assets/images/logo.svg';
class NavBar extends Component {

    constructor() {
        super();
        this.state = {}
    }
    render() {
        return (

            <div className="navBar">
                <Nav>
                    <NavItem style={{ marginLeft: "0.5%" }}>
                        <img src={logo} alt="logo" height="90" width="70"></img>
                    </NavItem>
                    <NavItem className="name">
                        <h2>VEHICLE SERVICING</h2>
                    </NavItem>
                    <NavItem className="navItem_home">
                        <NavLink exact to="/" activeClassName="Admin__Link__Active">HOME</NavLink><label className="nav_Seprator">|</label>
                    </NavItem>
                    <NavItem className="navItem">
                        <NavLink exact to="/aboutUs" activeClassName="Admin__Link__Active">ABOUT US</NavLink><label className="nav_Seprator">|</label>
                    </NavItem>
                    <NavItem className="navItem">
                        <NavLink to="/pricing" activeClassName="Admin__Link__Active">PRICING</NavLink><label className="nav_Seprator">|</label>
                    </NavItem>
                    <NavItem className="navItem">
                        <NavLink to="/ourOffers" activeClassName="Admin__Link__Active">OUR OFFERS</NavLink><label className="nav_Seprator">|</label>
                    </NavItem>
                    <NavItem className="navItem">
                        <NavLink exact to="/contactUs" activeClassName="Admin__Link__Active">CONTACT US</NavLink><label className="nav_Seprator">|</label>
                    </NavItem>
                    {/* <NavItem className="navItem">
                  <NavLink exact to="/" activeClassName="Admin__Link__Active" className="Admin__Link">BOOK NOW</NavLink><label className="nav_Seprator">|</label>
               </NavItem> */}
                    <NavItem className="navItem">
                        <NavLink to="/loginIn" activeClassName="Admin__Link__Active" >LOG IN</NavLink><label className="nav_Seprator">|</label>
                    </NavItem>
                    <NavItem className="navItem_signUp ml-auto">
                        <NavLink to="/register" activeClassName="Admin__Link__Active">SIGN UP</NavLink>
                    </NavItem>
                </Nav>
            </div>
        );
    }
}

export default NavBar;