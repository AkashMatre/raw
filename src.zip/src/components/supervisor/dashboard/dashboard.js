import React, { Component } from "react";
import { Table , TabContent, TabPane, Nav, NavItem, NavLink, Button, Row, Col, Collapse, CardBody } from "reactstrap";
import classnames from 'classnames';
import SupervisorNavbarComponent from '../supervisor-navbar';
import SupervisorSidebarComponent from '../supervisor-sidebar';
import "./Styled.css";
import { connect } from "react-redux";
import * as action from './dashboardAction';
import dashboardReducer from './dashboardReducer';

const vehicledata = [{
  date:"08/30/2019",
  vehicleType:"Honda Activa",
  customerName:"Jeffrey Garcia1",
  vehicleStatus: ""
},
{
  date:"12/30/2019",
  vehicleType:"Bajaj Chetak",
  customerName:"Jeffrey Garcia2",
  vehicleStatus: ""
},
{
  date:"09/30/2019",
  vehicleType:"Pulsar",
  customerName:"Jeffrey Garcia",
  vehicleStatus: ""
},
{
  date:"10/30/2019",
  vehicleType:"Vespa",
  customerName:"Jeffrey Garcia3",
  vehicleStatus: ""
},
{
  date:"11/30/2019",
  vehicleType:"Avenger",
  customerName:"Jeffrey Garcia4",
  vehicleStatus: ""
},
{
  date:"12/30/2019",
  vehicleType:"Honda City",
  customerName:"Jeffrey Garcia5",
  vehicleStatus: ""
}]


class SupervisorDashboard extends Component {
  state = {
    ischecked: false,
    activeTab: '1',
    collapse: 0,
    cards: [1, 2, 3, 4, 5],
  };

  multipleVehicleinfo = [];

  toggle = tab => {
    if(this.state.activeTab !== tab) {
      this.setState({
        activeTab: tab
      })
    }
	};

  openCollapse = (e) => {
    const event = e.target.dataset.event;
    this.setState({ collapse: this.state.collapse === Number(event) ? 0 : Number(event) });
  };
  
  saveVehicleStatus=()=>{
    console.log(this.multipleVehicleinfo , "########");
    document.getElementById("chkall").checked = false;
      const { dispatch } = this.props;
      dispatch(action.saveAssignEng(this.multipleVehicleinfo));
  }


  handleAllCheckboxChange = (targetdata,vehicledata) => {
     this.multipleVehicleinfo=[];
    for(let i = 0; i <= vehicledata.length-1; i++)
    {
      if(targetdata)
      {
          document.getElementById("chkbx" + i).checked = true; 
           this.multipleVehicleinfo.push(vehicledata[i]);
      }
      else{
          document.getElementById("chkbx" + i).checked = false;
      }
    }
  };

  handleCheckboxChange = (e, item, index) => {

      if(e.target.checked){
          this.multipleVehicleinfo.push(item);
       }
      else{
        document.getElementById("chkall").checked = false;
        for(let i=0 ; i<this.multipleVehicleinfo.length; i++)
        {
            if(this.multipleVehicleinfo[i].customerName===item.customerName && this.multipleVehicleinfo[i].vehicleType===item.vehicleType)
            {
              this.multipleVehicleinfo.splice(i,1);
            }  
        }          
      }
}

  render() {
    return (
      <div className="bodycolor">
				<SupervisorNavbarComponent />
				<SupervisorSidebarComponent />
        <div className="gridwrapper">
          <Nav tabs>
						<NavItem>
							<NavLink
								className={classnames({ active: this.state.activeTab === '1' })}
								onClick={() => { this.toggle('1'); }}
							>
								Vehical Assigned
							</NavLink>
						</NavItem>
						<NavItem>
							<NavLink
								className={classnames({ active: this.state.activeTab === '2' })}
								onClick={() => { this.toggle('2'); }}
							>
								Vehical Service Approval
							</NavLink>
						</NavItem>
						<NavItem>
							<NavLink
								className={classnames({ active: this.state.activeTab === '3' })}
								onClick={() => { this.toggle('3'); }}
							>
								Vehical Status
							</NavLink>
						</NavItem>
					</Nav>
          <TabContent activeTab={this.state.activeTab}>
						<TabPane tabId="1">
							<Row>
								<Col sm="12">
									<Table>
										<thead>
											<tr>
												<th><input  type="checkbox"
                          id="chkall"
                          onChange={e => {
                            this.handleAllCheckboxChange(e.target.checked , vehicledata);
                          }} /></th>
												<th>Date</th>
												<th>Vehicle Type</th>
												<th>Customer Name</th>
											</tr>
										</thead>
										<tbody>
                      {vehicledata.map((items,key) =>(
                        <tr>
                          <td><input type="checkbox"
                                          id={"chkbx"+key}
                                          key={items.date}
                                          ischecked={this.state.ischecked}
                                          onChange={e => {
                                            this.handleCheckboxChange(e, items, key);
                                          }}/></td>
                          <td>{items.date}</td>
                          <td>{items.vehicleType}</td>
                          <td>{items.customerName}</td>
                        </tr>

                      ))}
										</tbody>
									</Table>
								</Col>
							</Row>
              <Row>
                <Col sm="12">
                  <h4>Select Engineer</h4>
                  <select className="select-engineer">
                    <option value="">Select</option>
                    <option value="Scott">Scott</option>
                    <option value="Ben">Ben</option>
                  </select>
                  <Button color="warning" onClick={this.saveVehicleStatus}>Assign</Button>
                </Col>
              </Row>
						</TabPane>
						<TabPane tabId="2">
							<Row>
								<Col sm="12">
                  <Table>
										<thead>
											<tr>
												<th>Date</th>
												<th>Vehicle Type</th>
												<th>Customer Name</th>
												<th>Status</th>
												<th>View Details</th>
											</tr>
										</thead>
										<tbody>
                      {vehicledata.map((items,key) =>(
                        <React.Fragment>
                          <tr>
                            <td>{items.date}</td>
                            <td>{items.vehicleType}</td>
                            <td>{items.customerName}</td>
                            <td>{items.vehicalStatus}</td>
                            <td className="view-details" onClick={this.openCollapse} data-event={key}>View</td>
                          </tr>
                          <tr>
                            <td colspan="5" className="collapse-container">
                              <Collapse isOpen={this.state.collapse === key}>
                                <CardBody>
                                  Anim pariatur cliche reprehenderit,
                                  enim eiusmod high life accusamus terry richardson ad squid. Nihil
                                  anim keffiyeh helvetica, craft beer labore wes anderson cred
                                  nesciunt sapiente ea proident.
                                  <div>
                                    <h4>Engineer: <strong>Carl Jo</strong></h4>
                                    <select className="select-engineer">
                                      <option value="Not Approved">Not Approved</option>
                                      <option value="Approved">Approved</option>
                                    </select>
                                    <Button color="warning">Assign</Button>
                                  </div>
                                </CardBody>
                              </Collapse>
                            </td>
                          </tr>
                        </React.Fragment>
                      ))}
										</tbody>
									</Table>
								</Col>
							</Row>
						</TabPane>
            <TabPane tabId="3">
							<Row>
								<Col sm="12">
                  <Table>
										<thead>
											<tr>
												<th>Date</th>
												<th>Vehicle Type</th>
												<th>Customer Name</th>
												<th>Status</th>
												<th>View Details</th>
											</tr>
										</thead>
										<tbody>
                      {vehicledata.map((items,key) =>(
                        <React.Fragment>
                          <tr>
                            <td>{items.date}</td>
                            <td>{items.vehicleType}</td>
                            <td>{items.customerName}</td>
                            <td>{items.vehicalStatus}</td>
                            <td className="view-details" onClick={this.openCollapse} data-event={key}>View</td>
                          </tr>
                          <tr>
                            <td colspan="5" className="collapse-container">
                              <Collapse isOpen={this.state.collapse === key}>
                                <CardBody>
                                  Anim pariatur cliche reprehenderit,
                                  enim eiusmod high life accusamus terry richardson ad squid. Nihil
                                  anim keffiyeh helvetica, craft beer labore wes anderson cred
                                  nesciunt sapiente ea proident.
                                  <div>
                                    <h4>Supervisor</h4>
                                    <select className="select-engineer">
                                      <option value="">Select</option>
                                      <option value="Scott">Scott</option>
                                      <option value="Ben">Ben</option>
                                    </select>
                                    <Button color="warning">Assign</Button>
                                  </div>
                                </CardBody>
                              </Collapse>
                            </td>
                          </tr>
                        </React.Fragment>
                      ))}
										</tbody>
									</Table>
								</Col>
							</Row>
						</TabPane>
					</TabContent>
        </div>
      </div> 
    );
  }
}


const mapStateToProps = state => {
  return {
    // customersData: state.dashboardReducer.customersData || ""
  };
};


export default connect(mapStateToProps)(SupervisorDashboard);
