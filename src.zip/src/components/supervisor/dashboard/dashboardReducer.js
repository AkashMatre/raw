import * as actionTypes from "./dashboardActionType";
const profileReducer = (state = {}, action) => {
 
	//console.log(action.type, "action type", action.payload)
	switch (action.type) {
		case actionTypes.SUPERVISOR_STATUS_DETAILS:
		return Object.assign({}, state, {
			users: action.payload
		});
		 case actionTypes.CUSTOMERS_DETAILS:
		 return Object.assign({}, state, {
		 	customersData: action.payload
		 });

		default:
		return state;
	}
};
export default profileReducer;