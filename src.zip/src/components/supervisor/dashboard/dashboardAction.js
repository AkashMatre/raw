import * as actionTypes from "./dashboardActionType";
import axios from "axios";

export function customersDetails() {
  console.log("vehicle data")
  var headers = {
    "Content-Type": "application/json",
    // "x-auth-token": sessionStorage.getItem("token")
  }; 
  return function(dispatch) {
    return axios
      .get(`http://10.0.2.215:3000/supervisor/api/serviceRequests`)
      .then(res => {
        dispatch({
          type: actionTypes.CUSTOMERS_DETAILS,
          payload: res.data.data
        });
      });
  };
}

export function saveAssignEng(vehicleStatusData) {
    console.log("vehicle data" , vehicleStatusData)
  var headers = {
    "Content-Type": "application/json",
    // "x-auth-token": sessionStorage.getItem("token")
  }; 
  return async function(dispatch) {
    const res = await axios
      .put(`http://10.0.2.215:3000/supervisor/api/StatusSupervisor`, { vehicleStatusData }, { headers });
    dispatch({
      type: actionTypes.SUPERVISOR_STATUS_DETAILS,
      payload: res.data.data
    });
  };
}