import React, { Component } from "react";
import { Button, Form, FormGroup, Label, Input, Row, Col, FormText } from "reactstrap";
import SupervisorNavbarComponent from '../supervisor-navbar';
import SupervisorSidebarComponent from '../supervisor-sidebar';
import "./Styled.css";
import { connect } from "react-redux";
import * as action from './serviceAction';
import dashboardReducer from './serviceReducer';

class Service extends Component {

  render() {
    // console.log(document.getElementById("serviceType").innerText)
    return (
      <div className="bodycolor">
				<SupervisorNavbarComponent />
				<SupervisorSidebarComponent />
        <div className="gridwrapper">
          <Row>
            <Col>
              <h2>Service Request</h2>
            </Col>
          </Row>
          <Form>
            <Row>
              <Col md="6">
                <FormGroup>
                  <Input type="text" name="vehicalName" id="vehicalName" />
                  <Label for="vehicalName"></Label>
                </FormGroup>
              </Col>
            </Row>
          </Form>
          <Form className="service-form">
            <Row>
							<Col md="6">
                <FormGroup>
                  <Label for="categorySelect">Category:</Label>
                  <Input type="select" name="select" id="categorySelect">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                  </Input>
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalName">Vehicle Name:</Label>
                  <Input type="text" name="vehicalName" id="vehicalName" />
                </FormGroup>
              </Col>
            </Row>
            <Row>
							<Col md="6">
              <FormGroup>
                  <Label for="vehicalModel">Vehicle Model:</Label>
                  <Input type="text" name="vehicalModel" id="vehicalModel" />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalBrand">Vehicle Brand:</Label>
                  <Input type="text" name="vehicalBrand" id="vehicalBrand" />
                </FormGroup>
              </Col>
            </Row>
            <Row>
							<Col md="6">
                <FormGroup>
                  <Label for="vehicalRegNum">Vehicler Registration Number:</Label>
                  <Input type="text" name="vehicalRegNum" id="vehicalRegNum" />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="12">    
                <FormGroup>
                  <Label for="complaintText">Complaint:</Label>
                  <Input type="textarea" name="complaintText" id="complaintText" />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="6">  
                <FormGroup >
                  <FormGroup check inline>
                    <Label check>
                      <Input type="radio" className="form-check-input" id="pickup" name="serviceRadio" value="option1" defaultChecked />
                      Pickup
                    </Label>
                  </FormGroup>
                  <FormGroup check inline>
                    <Label check>
                      <Input type="radio" className="form-check-input" id="walkin" name="serviceRadio" value="option2" />
                      Walk-in
                    </Label>
                  </FormGroup>
                </FormGroup>
              </Col>
            </Row>
            <Row>
							<Col md="6">
                <FormGroup>
                  <Label for="date">Date:</Label>
                  <Input type="date" name="date" id="date" />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="time">Time:</Label>
                  <Input type="time" name="time" id="time" />
                </FormGroup>
              </Col>
            </Row>
            <hr />
            <Button color="warning">Submit</Button>
          </Form>
        </div>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    // vehicleDetails: state.dashboardskillReducer.deleteinfo || ""
  };
};


export default connect(mapStateToProps)(Service);