import React, { Component } from "react";
import { Button, Form, FormGroup, Label, Input, Row, Col, InputGroup, InputGroupAddon, InputGroupText } from "reactstrap";
import SupervisorNavbarComponent from '../supervisor-navbar';
import SupervisorSidebarComponent from '../supervisor-sidebar';
import "./Styled.css";
import { connect } from "react-redux";
import * as action from './serviceAction';
import dashboardReducer from './serviceReducer';

const customerData = [{
  phoneNumber:"4567345611",
  customerName:"Jeffrey Garcia1"
},
{
  phoneNumber:"4567345622",
  customerName:"Jeffrey Garcia2"
},
{
  phoneNumber:"4567345633",
  customerName:"Jeffrey Garcia"
},
{
  phoneNumber:"4567345644",
  customerName:"Jeffrey Garcia3"
},
{
  phoneNumber:"4567345655",
  customerName:"Jeffrey Garcia4"
},
{
  phoneNumber:"4567345666",
  customerName:"Jeffrey Garcia5"
}]

class Service extends Component {
  state = {
    phoneNumber: '',
    vehicalCategory: '1',
    vehicalName: '',
    vehicalModel: '',
    vehicalBrand: '',
    complaintText: '',
    serviceRadio: 'Pickup',
    date: '',
    time: '',
    phoneErrMsg: ''
  }

  findUser = () => {
    const enteredNumber = this.state.phoneNumber;
    const result = customerData.find( ({ phoneNumber }) => phoneNumber === enteredNumber );
    if (!result) {
      this.setState({
        phoneErrMsg: "This Customer is not registered."
      })
    }
  }

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }

  focusElement = () => {
    this.setState({
      phoneErrMsg: ""
    })
  }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state)
  }

  render() {
    return (
      <div className="bodycolor">
				<SupervisorNavbarComponent />
				<SupervisorSidebarComponent />
        <div className="gridwrapper">
          <Row>
            <Col md="6">
              <h2>Service Request</h2>
              <InputGroup className="search-bar">
                <Input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter Phone Number" onChange={this.handleChange.bind(this)} onFocus={this.focusElement.bind(this)} />
                <InputGroupAddon addonType="append">
                  <InputGroupText onClick={this.findUser.bind(this)}>Search</InputGroupText>
                </InputGroupAddon>
                <span className="error">{ this.state.phoneErrMsg ? this.state.phoneErrMsg : '' }</span>
              </InputGroup>
            </Col>
          </Row>
          <Form className="service-form">
            <Row>
							<Col md="6">
                <FormGroup>
                  <Label for="vehicalCategory">Category:</Label>
                  <Input type="select" name="vehicalCategory" id="vehicalCategory" onChange={this.handleChange.bind(this)}>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                  </Input>
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalName">Vehicle Name:</Label>
                  <Input type="text" name="vehicalName" id="vehicalName" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
            <Row>
							<Col md="6">
              <FormGroup>
                  <Label for="vehicalModel">Vehicle Model:</Label>
                  <Input type="text" name="vehicalModel" id="vehicalModel" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalBrand">Vehicle Brand:</Label>
                  <Input type="text" name="vehicalBrand" id="vehicalBrand" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
            <Row>
							<Col md="6">
                <FormGroup>
                  <Label for="vehicalRegNum">Vehicler Registration Number:</Label>
                  <Input type="text" name="vehicalRegNum" id="vehicalRegNum" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="12">    
                <FormGroup>
                  <Label for="complaintText">Complaint:</Label>
                  <Input type="textarea" name="complaintText" id="complaintText" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="6">  
                <FormGroup >
                  <FormGroup check inline>
                    <Label check>
                      <Input type="radio" className="form-check-input" id="pickup" name="serviceRadio" value="Pickup" onChange={this.handleChange.bind(this)} defaultChecked />
                      Pickup
                    </Label>
                  </FormGroup>
                  <FormGroup check inline>
                    <Label check>
                      <Input type="radio" className="form-check-input" id="walkin" name="serviceRadio" value="Walk-in" onChange={this.handleChange.bind(this)} />
                      Walk-in
                    </Label>
                  </FormGroup>
                </FormGroup>
              </Col>
            </Row>
            <Row>
							<Col md="6">
                <FormGroup>
                  <Label for="date">Date:</Label>
                  <Input type="date" name="date" id="date" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="time">Time:</Label>
                  <Input type="time" name="time" id="time" onChange={this.handleChange.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
            <hr />
            <Button color="warning" onClick={this.handleSubmit.bind(this)} disabled={this.state.phoneErrMsg || !this.state.phoneNumber}>Submit</Button>
          </Form>
        </div>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    // vehicleDetails: state.dashboardskillReducer.deleteinfo || ""
  };
};


export default connect(mapStateToProps)(Service);