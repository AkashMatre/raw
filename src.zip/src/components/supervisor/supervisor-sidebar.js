import React, { useState } from 'react'
import { NavItem, NavLink, Nav, Dropdown, DropdownItem, DropdownToggle, DropdownMenu } from 'reactstrap';
import { Link } from 'react-router-dom';
import './supervisor.css';

const SupervisorSidebarComponent = (props) => {
  return (
    <div className="styledsidenav">
      <div className="">
        <div className="side-menu">
          <Nav vertical className="list-unstyled pb-3">
            <NavItem>
              <Link to="/"><NavLink>DASHBOARD</NavLink></Link>
            </NavItem>
            <NavItem>
              <Link to="/service"><NavLink>SERVICE</NavLink></Link>
            </NavItem>
          </Nav>

        </div>
      </div>
    </div>
  )
}


export default SupervisorSidebarComponent;
