import * as actionTypes from './vehicle-booking-actiontype';

const vehicleBookingReducer = (state = {}, action) => {
    switch (action.type) {
        case actionTypes.VEHICLE_BOOKING_SUCCESS:
            return Object.assign({}, state, {
                vehicleBookingSuccess: action.payload
            });
        default:
            return state;
    }
};
export default vehicleBookingReducer;