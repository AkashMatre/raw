import React, { Component } from 'react'
import CustomerNavbarComponent from '../customer-navigation/customer-navbar';
import CustomerSidebarComponent from '../customer-navigation/customer-sidebar';

 class VehicleHistoryComponent extends Component {
    render() {
        return (
            <div className="bodycolor">
                <CustomerNavbarComponent />
                <CustomerSidebarComponent />
                  <div className="gridwrapper">
                    <h4>Vehicle Booking</h4>      
                    <table class="table">
                        <thead class="table-active">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Service Date</th>
                                <th>Vehicle Type</th>
                                <th></th>                               
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>        
        )
    }
}
export default VehicleHistoryComponent;
