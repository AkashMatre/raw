import axios from "axios";
import * as actionTypes from "./vehicle-booking-actiontype";

export function vehiclebooking(vehicle) {  
  var headers = {
    "Content-Type": "application/json",
    //"x-auth-token": sessionStorage.getItem("token")
  };
  return function(dispatch) {
    return axios
      .post(`http://10.0.2.215:3000/supervisor/api/createServiceRequest/`, { vehicle } , { headers } 
      )
      .then(res => {
        dispatch({
          type: actionTypes.VEHICLE_BOOKING_SUCCESS,
          payload: res.data.data
        });
      });
  };
}