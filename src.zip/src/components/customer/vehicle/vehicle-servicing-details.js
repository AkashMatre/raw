import React, { Component } from 'react'
import '../customer.css';

 class VehicleServicingDetailsComponent extends Component {
    render() {
        return (
            <div className="gridwrapper">
                VehicleServicingDetailsComponent
                <p>This is a paragraph and I am writing on the home page</p>
                <p>This is another paragraph, hi hey hello whatsup yo</p>
            </div>
        )
    }
}
export default VehicleServicingDetailsComponent;
