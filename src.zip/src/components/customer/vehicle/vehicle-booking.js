import React, { Component } from 'react'
import CustomerNavbarComponent from '../customer-navigation/customer-navbar';
import CustomerSidebarComponent from '../customer-navigation/customer-sidebar';

 class VehicleBookingComponent extends Component {
    render() {
        return (
           <div className="bodycolor">
                <CustomerNavbarComponent />
                <CustomerSidebarComponent />
                 <div className="gridwrapper">
                    <div className="col-md-10">
                    <div className="col-md-12">
                      <h4>Vehicle Booking</h4>                      
                      <div className="box">
                        <div className="row">
                          <div className="col-sm-6 form-group">
                            <div className="form-group">
                              <label htmlFor="category">
                                Category:
                              </label>
                              <br />                             
                                <select
                                    className="form-control"
                                    name="category"
                                ><option>Select</option>                           
                                </select>
                            </div>
                            <div className="form-group">
                              <label htmlFor="vehiclemodel">
                                Vehicle Model:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehiclemodel"
                                id="vehiclemodel"
                                className="form-control"
                                
                              />
                            </div>
                            <div className="form-group">
                              <label htmlFor="vehicleregistrationnumber">
                                Vehicler Rgistration Number:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehicleregistrationnumber"
                                id="vehicleregistrationnumber"
                                className="form-control"
                               
                              />
                            </div>   
                          </div>
                          <div className="col-sm-6 form-group">
                            <div className="form-group">
                              <label htmlFor="phonenumber">
                                Phone Number:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="phonenumber"
                                id="phonenumber"
                                className="form-control"                                
                              />
                            </div>   
                            <div className="form-group">
                              <label htmlFor="vehiclename">
                                Vehicle Name:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehiclename"
                                id="vehiclename"
                                className="form-control"                               
                              />
                            </div>
                            <div className="form-group">
                              <label htmlFor="vehiclebrand">
                                Vehicle Brand:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehiclebrand"
                                id="vehiclebrand"
                                className="form-control"                                
                              />
                            </div> 
                           
                          </div>

                          <div className="col-sm-12 form-group">                              
                              <label htmlFor="complaint">
                                Complaint:
                              </label>
                              <br />
                              <textarea 
                                className="form-control" 
                                rows="4"  
                                name="complaint"
                                id="complaint">
                              </textarea>                              
                            </div>  

                            <div className="col-sm-6 form-group">
                            <div className="form-group">
                              <label htmlFor="vehicledeliverytype">
                                Vehicle Delivery Type:
                              </label>
                              <br />                              
                              <div className="form-check-inline">
                                  <label className="vehicledeliverylabel" htmlFor="pickup">
                                      <input 
                                        type="radio" 
                                        className="form-check-input" 
                                        id="pickup" 
                                        name="vehicledeliveryradio" 
                                        value="option1" 
                                        defaultChecked />
                                        Pickup
                                  </label>
                              </div>
                              <div className="form-check-inline">
                                  <label className="vehicledeliverylabel" htmlFor="walkin">
                                      <input 
                                        type="radio" 
                                        className="form-check-input" 
                                        id="walkin" 
                                        name="vehicledeliveryradio" 
                                        value="option2" />
                                        Walk-in
                                  </label>
                              </div>
                            </div> 
                          </div>     
                          <div className="col-sm-6 form-group"></div>      
                           <div className="col-sm-6 form-group">                           
                            <div className="form-group">
                              <label htmlFor="date">
                                Date:
                              </label>
                              <br />
                              <input
                                type="date"
                                name="date"
                                id="date"
                                className="form-control"                                
                              />
                            </div>
                            </div>           
                            <div className="col-sm-6 form-group">                           
                            <div className="form-group">
                              <label htmlFor="time">
                                Time:
                              </label>
                              <br />
                              <input
                                type="time"
                                name="time"
                                id="time"
                                className="form-control"                                
                              />
                            </div>
                            </div>                                           
                        </div>  
                       <hr />
                       <br />
                        <div className="col-sm-6 form-group">                           
                              <input
                                type="submit"
                                name="submit"
                                className="btn btn-warning btn-md form-control"
                                value="SUBMIT"               
                              />                              
                        </div>                      
                      </div>
                    </div>
                  </div>
                 </div>
            </div>
        )
    }
}
export default VehicleBookingComponent;
