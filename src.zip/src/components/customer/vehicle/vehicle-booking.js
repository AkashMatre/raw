import React, { Component } from 'react'
import CustomerNavbarComponent from '../customer-navigation/customer-navbar';
import CustomerSidebarComponent from '../customer-navigation/customer-sidebar';
import { Button, Form, FormGroup, Label, Input, Row, Col, FormText } from "reactstrap";
// import vehiclebooking from './vehicle-booking-action';
class VehicleBookingComponent extends Component {
  constructor(props){
    super(props);
    this.state = {
      category: '',
      phoneNumber: '',
      vehicalModel: '',
      vehicalName: '',
      vehicalRegistrationNumber: '',
      vehicalBrand: '',
      complaint: '',
      serviceRadio: '',
      date: '',
      time: ''
    }
    
    // this.serv = new vehiclebooking();
  }  

  onPropertyChange(e){
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  onPersonSubmit(){
    let booking = {
      phoneNumber: this.state.phoneNumber,
      vehicalModel: this.state.vehicalModel,
      vehicalName: this.state.vehicalName,
      vehicalRegistrationNumber: this.state.vehicalRegistrationNumber,
      vehicalBrand: this.state.vehicalBrand,
      complaint: this.state.complaint,
      serviceRadio: this.state.serviceRadio,
      date: this.state.date,
      time: this.state.time
    };

  }

  render() {
    return (
      <div className="bodycolor">
        <CustomerNavbarComponent />
        <CustomerSidebarComponent />
           <div className="gridwrapper">
          <Row>
            <Col>
              <h4>Vehicle Booking</h4>  
            </Col>
          </Row>         
          <Form className="service-form">
            <Row>
              <Col md="6">
                <FormGroup>
                  <Label for="categorySelect">Category:</Label>
                  <Input type="select" name="select" id="categorySelect">
                    <option>Select</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                  </Input>
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="phonenumber">Phone Number:</Label>
                  <Input 
                  type="text" 
                  name="phoneNumber" 
                  id="phoneNumber" 
                  value={this.state.phoneNumber}
                  onChange={this.onPropertyChange.bind(this)}
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalModel">Vehicle Model:</Label>
                  <Input 
                  type="text" 
                  name="vehicalModel" 
                  id="vehicalModel" 
                  value={this.state.vehicalModel}
                  onChange={this.onPropertyChange.bind(this)}
                  />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalName">Vehicle Name:</Label>
                  <Input 
                  type="text" 
                  name="vehicalName" 
                  id="vehicalName" 
                  value={this.state.vehicalName}
                  onChange={this.onPropertyChange.bind(this)}
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalRegistrationNumber">Vehicler Registration Number:</Label>
                  <Input 
                  type="text" 
                  name="vehicalRegistrationNumber" 
                  id="vehicalRegistrationNumber" 
                  value={this.state.vehicalRegistrationNumber}
                  onChange={this.onPropertyChange.bind(this)}
                  />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="vehicalBrand">Vehicle Brand:</Label>
                  <Input 
                  type="text" 
                  name="vehicalBrand" 
                  id="vehicalBrand" 
                  value={this.state.vehicalBrand}
                  onChange={this.onPropertyChange.bind(this)}
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="12">
                <FormGroup>
                  <Label for="complaint">Complaint:</Label>
                  <Input 
                  type="textarea" 
                  name="complaint" 
                  id="complaint" 
                  value={this.state.complaint}
                  onChange={this.onPropertyChange.bind(this)}
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="6">
                <FormGroup >
                  <FormGroup check inline>
                    <Label check>
                      <Input 
                      type="radio" 
                      className="form-check-input" 
                      id="pickup" 
                      name="serviceRadio" 
                      value="option1" 
                      defaultChecked 
                      value={this.state.serviceRadio}
                      onChange={this.onPropertyChange.bind(this)}                      
                      />
                      Pickup
                    </Label>
                  </FormGroup>
                  <FormGroup check inline>
                    <Label check>
                      <Input 
                      type="radio" 
                      className="form-check-input" 
                      id="walkin" 
                      name="serviceRadio" 
                      value="option2" 
                      value={this.state.serviceRadio}
                      onChange={this.onPropertyChange.bind(this)}  
                      />
                      Walk-in
                    </Label>
                  </FormGroup>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="6">
                <FormGroup>
                  <Label for="date">Date:</Label>
                  <Input 
                  type="date" 
                  name="date" 
                  id="date" 
                  value={this.state.date}
                  onChange={this.onPropertyChange.bind(this)}  
                  />
                </FormGroup>
              </Col>
              <Col md="6">
                <FormGroup>
                  <Label for="time">Time:</Label>
                  <Input 
                  type="time" 
                  name="time" 
                  id="time" 
                  value={this.state.time}
                  onChange={this.onPropertyChange.bind(this)}  
                  />
                </FormGroup>
              </Col>
            </Row>
            <hr />
            <Button color="warning">Submit</Button>
          </Form>
        </div>
        {/* <div className="gridwrapper">
                    <div className="col-md-10">
                    <div className="col-md-12">
                      <h4>Vehicle Booking</h4>                      
                      <div className="box">
                        <div className="row">
                          <div className="col-sm-6 form-group">
                            <div className="form-group">
                              <label htmlFor="category">
                                Category:
                              </label>
                              <br />                             
                                <select
                                    className="form-control"
                                    name="category"
                                ><option>Select</option>   
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>                        
                                </select>
                            </div>
                            <div className="form-group">
                              <label htmlFor="vehiclemodel">
                                Vehicle Model:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehiclemodel"
                                id="vehiclemodel"
                                className="form-control"
                                
                              />
                            </div>
                            <div className="form-group">
                              <label htmlFor="vehicleregistrationnumber">
                                Vehicler Rgistration Number:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehicleregistrationnumber"
                                id="vehicleregistrationnumber"
                                className="form-control"
                               
                              />
                            </div>   
                          </div>
                          <div className="col-sm-6 form-group">
                            <div className="form-group">
                              <label htmlFor="phonenumber">
                                Phone Number:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="phonenumber"
                                id="phonenumber"
                                className="form-control"                                
                              />
                            </div>   
                            <div className="form-group">
                              <label htmlFor="vehiclename">
                                Vehicle Name:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehiclename"
                                id="vehiclename"
                                className="form-control"                               
                              />
                            </div>
                            <div className="form-group">
                              <label htmlFor="vehiclebrand">
                                Vehicle Brand:
                              </label>
                              <br />
                              <input
                                type="text"
                                name="vehiclebrand"
                                id="vehiclebrand"
                                className="form-control"                                
                              />
                            </div> 
                           
                          </div>

                          <div className="col-sm-12 form-group">                              
                              <label htmlFor="complaint">
                                Complaint:
                              </label>
                              <br />
                              <textarea 
                                className="form-control" 
                                rows="4"  
                                name="complaint"
                                id="complaint">
                              </textarea>                              
                            </div>  

                            <div className="col-sm-6 form-group">
                            <div className="form-group">
                              <label htmlFor="vehicledeliverytype">
                                Vehicle Delivery Type:
                              </label>
                              <br />                              
                              <div className="form-check-inline">
                                  <label className="vehicledeliverylabel" htmlFor="pickup">
                                      <input 
                                        type="radio" 
                                        className="form-check-input" 
                                        id="pickup" 
                                        name="vehicledeliveryradio" 
                                        value="option1" 
                                        defaultChecked />
                                        Pickup
                                  </label>
                              </div>
                              <div className="form-check-inline">
                                  <label className="vehicledeliverylabel" htmlFor="walkin">
                                      <input 
                                        type="radio" 
                                        className="form-check-input" 
                                        id="walkin" 
                                        name="vehicledeliveryradio" 
                                        value="option2" />
                                        Walk-in
                                  </label>
                              </div>
                            </div> 
                          </div>     
                          <div className="col-sm-6 form-group"></div>      
                           <div className="col-sm-6 form-group">                           
                            <div className="form-group">
                              <label htmlFor="date">
                                Date:
                              </label>
                              <br />
                              <input
                                type="date"
                                name="date"
                                id="date"
                                className="form-control"                                
                              />
                            </div>
                            </div>           
                            <div className="col-sm-6 form-group">                           
                            <div className="form-group">
                              <label htmlFor="time">
                                Time:
                              </label>
                              <br />
                              <input
                                type="time"
                                name="time"
                                id="time"
                                className="form-control"                                
                              />
                            </div>
                            </div>                                           
                        </div>  
                       <hr />
                       <br />
                        <div className="col-sm-6 form-group">                           
                              <input
                                type="submit"
                                name="submit"
                                className="btn btn-warning btn-md form-control"
                                value="SUBMIT"               
                              />                              
                        </div>                      
                      </div>
                    </div>
                  </div>
                 </div> */}
     
      </div>
    )
  }
}
export default VehicleBookingComponent;
