import React, { Component } from 'react'
import CustomerNavbarComponent from '../customer/customer-navigation/customer-navbar';
import CustomerSidebarComponent from '../customer/customer-navigation/customer-sidebar';
import '../customer/customer-navigation/customer.css';

class CustomerComponent extends Component {
    render() {
        return (
            <div className="bodycolor">
                <CustomerNavbarComponent />
                <CustomerSidebarComponent />
                <div className="gridwrapper">
                    <div className="col-sm-6 form-group">
                        <div className="form-group text-center">
                            <div className="input-group">
                                <input
                                    type="text"
                                    name="trackingid"
                                    className="form-control"
                                    placeholder="Tracking ID"

                                />
                                <span className="input-group-btn">
                                    <input
                                        type="submit"
                                        name="submit"
                                        className="btn btn-warning btn-md"
                                        value="CHECK STATUS"

                                    />
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div className="tablebox">
                    <h5>Vehicle Servicing Details</h5>
                    <table className="table">
                        <thead className="table-active">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Service Date</th>
                                <th>Vehicle Type</th>
                                <th>Status</th>
                                <th>Bill Details</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                    </div>

                </div>

            </div>
        )
    }
}

export default CustomerComponent;
