import React, { Component } from 'react'
import HeaderComponent from '../NavBar/NavBar';

class BookNow extends Component {
    render() {
        return (
            <div>
                <HeaderComponent />
                BookNowComponent
            </div>
        )
    }
}
export default BookNow;
