import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { Nav, NavItem,   Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem
     } from 'reactstrap';
import logo from '../../../assets/images/logo.svg';

class NavBar extends Component {

    constructor() {
        super();
        this.state = {}
    }
    render() {
        return ( 

            <div className="navBar">
                <Nav className="nav-style" style={{
    justifyContent: "flex-start"}}>
                    <NavItem   style={{ marginLeft: "0.5%" }}>
                        <img src={logo} alt="logo" height="90" width="70"></img>
                    </NavItem>
                    <NavItem className="name">
                        <h2>VEHICLE SERVICING</h2>
                    </NavItem>
                    <Navbar color="" dark expand="md"  style={{
    justifyContent: "flex-end"}}>
                    <NavbarToggler />
                    <Collapse navbar>
                        <Nav className="ml-auto" navbar>   
                        <i class="fa fa-bell" aria-hidden="true"></i>
                        
                            <UncontrolledDropdown nav inNavbar>

                                <DropdownToggle nav caret>                                        
                                    Hello {` ` + localStorage.getItem("name")}
                            </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>                                                          
                                        My Profile
                            </DropdownItem>
                            <DropdownItem divider />
                                    <DropdownItem>
                                        Change Password
                            </DropdownItem>
                                    <DropdownItem divider />
                                    <DropdownItem>
                                        Logout
                            </DropdownItem>
                                </DropdownMenu>
                            </UncontrolledDropdown>                           
                        </Nav>
                    </Collapse>
                    </Navbar>
                    
                  
                </Nav>
         
            </div>
            
        );
    }
}

export default NavBar;