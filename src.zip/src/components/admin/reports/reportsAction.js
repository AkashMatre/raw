import * as actionTypes from "./reportsActionType";
import axios from "axios";
import * as api from "../../../config";

export function getCustomerBillDetails(fromDate, toDate) {

  console.log(api.API_URL, "API_URL", fromDate, toDate);
  var headers = {
    "Content-Type": "application/json",
    // "x-auth-token": sessionStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .get(api.API_URL + `/admin/api/enquiremessage`, { fromDate: fromDate, toDate: toDate })
      .then(res => {
        dispatch({
          type: actionTypes.CUSTOMER_BILL_DETAILS,
          payload: res.data.data
        });
      });
  };
}

// export function replyMessage(messageInputs) {

//   console.log(messageInputs , "messageInputs");

//   console.log(api.API_URL , "API_URL");
//   var headers = {
//     "Content-Type": "application/json",
//     // "x-auth-token": sessionStorage.getItem("token")
//   }; 
//   return function(dispatch) {
//     return axios
//       .get(api.API_URL+`/admin/api/replymessages`)
//       .then(res => {
//         dispatch({
//           type: actionTypes.REPLY_FOR_MESSAGES,
//           payload: res.data.data
//         });
//       });
//   };
// }