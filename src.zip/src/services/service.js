import { API_URL } from "./../config.js";
import axios from "axios";

export const onLogin = login => {
  return new Promise((resolve, reject) => {
    console.log("In Service :", login);
    axios({
      method: "post",
      url: API_URL + "/users/api/authenticate",
      config: {
        headers: {
          "content-type": "application/json"
        }
      },
      data: login
    })
      .then(function (response) {
        if (response) {
          resolve(response);
        }
      })
      .catch(function (error) {
        resolve(error);
      });
  });
};

export const registerUser = register => {
  return new Promise((resolve, reject) => {
    console.log("In Service :", register);
    axios({
      method: "post",
      url: API_URL + "/users/api/register",
      config: {
        headers: {
          "content-type": "application/json"
        }
      },
      data: register
    })
      .then(function (response) {
        if (response) {
          resolve(response);
        }
      })
      .catch(function (error) {
        resolve(error);
      });
  });
};

export const otpVerify = otp => {
  return new Promise((resolve, reject) => {
    console.log("In Service :", otp);
    axios({
      method: "put",
      url: API_URL + "/users/api/verifyOTP",
      config: {
        headers: {
          "content-type": "application/json"
        }
      },
      data: otp
    })
      .then(function (response) {
        if (response) {
          resolve(response);
        }
      })
      .catch(function (error) {
        resolve(error);
      });
  });
};


export const contactUs = contact => {
  return new Promise((resolve, reject) => {
    console.log("In Service :", contact);
    axios({
      method: "post",
      url: API_URL + "/admin/api/contactus",
      config: {
        headers: {
          "content-type": "application/json"
        }
      },
      data: contact
    })
      .then(function (response) {
        if (response) {
          resolve(response);
        }
      })
      .catch(function (error) {
        resolve(error);
      });
  });
};
