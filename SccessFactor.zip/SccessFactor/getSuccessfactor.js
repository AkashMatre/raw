const axios = require('axios');
const UserModel = require('./userModel');


const getSuccessFactor = async () => {

    const credentials = {
        UserName: "apiadmin@C0014228534T1",
        password: "SPD^dmin080"
    }
    let data = 'apiadmin@C0014228534T1:SPD^dmin080';
    let buff = new Buffer(data);
    let base64data = buff.toString('base64');
    var headers = {
        "Authorization": "Basic " + base64data
    }

    let res = await axios.get(
        'https://api10.successfactors.com/odata/v2/User?$format=json&$expand=manager&$select=userId,defaultFullName,jobTitle,email,manager/userId,manager/defaultFullName,manager/email',
        { headers: headers }
    );
    var obj = new Object()
    var titles = res.data.d.results.map(item => item.jobTitle).filter((value, index, self) => self.indexOf(value) === index);
    obj = titles;
    console.log(titles.length, "titles");
    for (let i = 0; i <= titles.length; i++) {
        console.log(titles[i]);
    }



    console.log(res.data.d.results, "result");
    for (let i = 637; i <= res.data.d.results.length - 1; i++) {
        if (res.data.d.results[i].userId !== undefined) {
            managers = [];
            if (res.data.d.results[i].manager === null) {
                managers.push({ userId: "", name: "", email: "" });
            }
            else {
                managers.push({ userId: res.data.d.results[i].manager.userId, name: res.data.d.results[i].manager.defaultFullName, email: res.data.d.results[i].manager.email });
            }
            // console.log("Employee ID := "+ res.data.d.results[i].userId);
            // console.log("Employee Name := "+ res.data.d.results[i].defaultFullName);
            // console.log("Employee Designation := "+ res.data.d.results[i].jobTitle);
            // console.log("Employee Email Address := "+ res.data.d.results[i].email);  
            // console.log("Managers:=" + JSON.stringify(managers));
            // console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+i);
            //  UserModel.insertMany([{username:res.data.d.results[i].email , firstname:res.data.d.results[i].defaultFullName , 
            //     lastname:res.data.d.results[i].defaultFullName ,managers:[],
            // empid:"",fullname:"",designation:"",
            // email:""}]);
            try {
                const result = await UserModel.findOneAndUpdate({ username: res.data.d.results[i].email },
                    {
                        managers: managers, empid: res.data.d.results[i].userId, fullname: res.data.d.results[i].defaultFullName,
                        designation: res.data.d.results[i].jobTitle, email: res.data.d.results[i].email
                    });
                console.log(result);
                // const result = await UserModel.findOneAndUpdate({firstname:res.data.d.results[i].defaultFullName},
                //     {managers:managers,empid:res.data.d.results[i].userId,fullname:res.data.d.results[i].defaultFullName,
                //     designation:res.data.d.results[i].jobTitle,email:res.data.d.results[i].email}); 
                //     await UserModel.findOneAndUpdate({firstname:res.data.d.results[i].manager.defaultFullName} , {role:"DM"});

                //  console.log(result);


            }
            catch (error) {
                console.log("error from api", error);
            }
        }
    }
}
module.exports = {
    getSuccessFactor
}