const express = require('express');
const axios = require('axios');
const mongoose = require("mongoose");
const getSuccessFactor = require('./getSuccessfactor');
const setApprovalAuthority = require('./setApprovalAuthority');
const userValidation = require('./userValidation');
const getSuccessfactorData = require('./getSuccessfactorData');
const setImmedietDM = require('./addImmedietDM');
const skillMasterData = require('./skillMasterData');
const sendEmail = require('./emailUtil');
const getMatrixSkillsData = require('./matrixSkills');
const readExcel = require('./readExcel');

const cron = require("node-cron");
const nodeMailer = require("nodemailer");

const app = express()
const port = 5000

mongoose.connect("mongodb://localhost:27017/Skill_Inventory", function (error) {
  if (error)
  {
    console.log(error);
  } else
  {
    console.log("connection successfull");
  }
})

//readExcel.readExcel();
//getSuccessfactorData.getSuccessfactorData()
// skillMasterData.skillMasterData();
 //getMatrixSkillsData.getMatrixSkillsData();

cron.schedule("*/5 * * * *", function () {
const invokeThread = (async () => {
  console.log("start time : " ,new Date());
  //sendEmail.sendEmail();
  await skillMasterData.skillMasterData();
  await getSuccessfactorData.getSuccessfactorData().then((res)=>{});
  await setImmedietDM.setImmedietDM();
  await setApprovalAuthority.setDmAuthority();
  await readExcel.readExcel();
  //userValidation.userValidation();
  console.log("end time : " ,new Date());
})()
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))