const express = require('express');
const axios = require('axios');
const mongoose = require("mongoose");
const getSuccessFactor = require('./getSuccessfactor');
const setApprovalAuthority = require('./setApprovalAuthority');
const userValidation = require('./userValidation');
const getSuccessfactorData = require('./getSuccessfactorData');
const setImmedietDM = require('./addImmedietDM');
const skillMasterData = require('./skillMasterData');
const sendEmail = require('./emailUtil');

const cron = require("node-cron");
const nodeMailer = require("nodemailer");

const app = express()
const port = 5000

mongoose.connect("mongodb://localhost:27017/Skill_Inventory", function (error) {
  if (error)
  {
    console.log(error);
  } else
  {
    console.log("connection successfull");
  }
})
app.get('/', (req, res) => res.send('Hello World!'));

console.log(new Date());

//sendEmail.sendEmail();
//skillMasterData.skillMasterData();
//getSuccessfactorData.getSuccessfactorData();
//setImmedietDM.setImmedietDM();
//setApprovalAuthority.setDmAuthority();
//userValidation.userValidation();

//getSuccessFactor.getSuccessFactor();


cron.schedule("* * * * *", function () {
  console.log("Running Cron Job at :" , new Date());
 
});


// cron.schedule("* * * * *", function () {
//   console.log("Running Cron Job");
//   // getSuccessFactor.getSuccessFactor();
// });

app.listen(port, () => console.log(`Example app listening on port ${port}!`))