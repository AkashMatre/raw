const mongoose = require("mongoose");
var Schema = mongoose.Schema;
var DmSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    role: { type: String, default: "Employee" },
    designation: {
        type: String,
    },
    email: {
        type: String,
    },
    location: {
        type: String
    },
    isCapDev: {
      type: String,
      default: "NA"
    },
    isDM: {
      type: String,
      default: "NA"
    },
    isDirectApprove: {
      type: String,
      default: "NA"
    },
});
const DmModel = mongoose.model("approve_authority", DmSchema, "approve_authority");
module.exports = DmModel;
