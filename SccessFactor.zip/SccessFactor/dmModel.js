const mongoose = require("mongoose");
var Schema = mongoose.Schema;
var DmSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    firstname: {
        type: String,
        required: true
    },
    lastname: {
        type: String
    },
    role: { type: String, default: "Employee" },
    designation: {
        type: String,
    },
    email: {
        type: String,
    },
    location: {
        type: String
    }
});
const DmModel = mongoose.model("approve_authority", DmSchema, "approve_authority");
module.exports = DmModel;
