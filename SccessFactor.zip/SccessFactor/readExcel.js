var XLSX = require('xlsx');
const axios = require('axios');
const DmModel = require('./dmModel');
const readExcel = async () => {
var workbook = XLSX.readFile('Skill_Cloud_Approval_Authority.xlsx');
var sheet_name_list = workbook.SheetNames;
var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
const {EmpSkillsmapModel,SkillsMastermapModel} = require('./skillModel');
const UserModel = require('./userModel');

const credentials = {
    UserName: "apiadmin@C0014228534T1",
    password: "SPD^dmin080"
}

let data = 'mis-prod:P@ssw0r!)#';
let buff = new Buffer(data);
let base64data = buff.toString('base64');
var headers = {
    "Authorization": "Basic " + base64data
}
let res = await axios.get(
    'http://10.0.10.129:3000/successfactors/getEmpInfo',
    { headers: headers }
);
let managers = [];
const empResult = res && res.data && res.data.d && res.data.d.results;
for (let i = 0; i <= empResult.length - 1; i++)
{
    if (empResult[i].email !== "NA"  && empResult[i].email !== undefined && empResult[i].email !== null)
    {
        let empupdtMail = ""
        let empemailSplit = empResult[i].email.split("@")[0];
        const empres = empemailSplit.split(".");
        let emplnewMail = ""
        if (empemailSplit.includes("."))
        {
            const empres = empemailSplit.split(".");
            firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
            lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
            empupdtMail = firstName + "." + lastName + "@" + empResult[i].email.split("@")[1].toLowerCase();
        } else
        {
            firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + empResult[i].email.split("@")[1].toLowerCase();
            empupdtMail = firstName;
        }

        xlData.map((data,key)=>{
            if(empResult[i].defaultFullName === data.Name)
            {
                // const insertAllRecord =  DmModel.insertMany({
                //                 username:empupdtMail,name:data.Name,designation:data.Designation,email:empupdtMail,location:data.Location,isDM:data.ISDM,isDirectApprove:data.DirectApproval,isCapDev:data.CapDev      
                //             }); 
            }
         })
    } 
}
const result =  DmModel.find({}, function(err,data){
    data.map((data)=>{
        console.log(data);
                    if(data.isDirectApprove === 'Yes')
                        {
                            try {
                                    const result =  EmpSkillsmapModel.updateMany({ username: data.email},{skillStatus:"approved"}, function(err,data){});  
                                } catch (error) {
                                        console.log(error);
                                    }
                                }
                                try {
                                    const result =  DmModel.updateMany({ username: data.email},{isDM:"Yes"}, function(err,data){});  
                                } catch (error) {
                                        console.log(error);
                        }
                        if(data.isCapDev === 'Yes')
                        {
                            try {
                                    const result =  UserModel.updateMany({ username: data.email},{role:"CapDev"}, function(err,data){});  
                                } catch (error) {
                                        console.log(error);
                                    }
                        }        
                    })                    
});
}

module.exports = {
    readExcel
}