const UserModel = require('./userModel');
const DmModel = require('./dmModel');
const axios = require('axios');
const setDmAuthority = async () => {

    let data = 'mis-prod:P@ssw0r!)#';
    let buff = new Buffer(data);
    let base64data = buff.toString('base64');
    var headers = {
        "Authorization": "Basic " + base64data
    }

    let res = await axios.get(
        'http://10.0.10.129:3000/successfactors/getEmpInfo',
        { headers: headers }
    );

    const getDirectsManager = async (emplyeeEmail, managersEmail = "") => {
        try
        {
            let email = managersEmail ? managersEmail : emplyeeEmail
            let userDetails = await UserModel.findOne({ username: email });
            console.log(userDetails.managers.email,"userDetails.managers.email")
            let userRole = await UserModel.findOne({ username: userDetails.managers.email });

            if (userRole.role === "DM")
            {
                await UserModel.findOneAndUpdate({ username: emplyeeEmail }, { "managers.email": userDetails.managers.email });
                // update query
                return "success";
            } else
            {
                await getDirectsManager(emplyeeEmail, userDetails.managers.email);
            }

        } catch (error)
        {
            console.error(error);
        }
    }

    const empResult = res && res.data && res.data.d && res.data.d.results;

    for (let i = 0; i <= empResult.length - 1; i++)
    {
       // console.log(empResult[i].manage , "empResult[i].manage");

        if (empResult[i].email !== "NA" && empResult[i].manager !== null && empResult[i].manager !== "" && empResult[i].email !== undefined && empResult[i].userId !== undefined && empResult[i].email !== undefined && empResult[i].manager !== undefined && empResult[i].role !== null)
        {
            console.log(empResult[i].manager , "empResult[i].manage1");
            let empupdtMail = ""
            let empemailSplit = empResult[i].email.split("@")[0];
            const empres = empemailSplit.split(".");
            //  let emplnewMail = ""
            if (empemailSplit.includes("."))
            {
                const empres = empemailSplit.split(".");
                firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
                lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
                empupdtMail = firstName + "." + lastName + "@" + empResult[i].email.split("@")[1].toLowerCase();
            } else
            {
                firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + empResult[i].email.split("@")[1].toLowerCase();
                empupdtMail = firstName;
            }
            let managerDetails = getDirectsManager(empupdtMail)

        }
    }
}

module.exports = {
    setDmAuthority
}