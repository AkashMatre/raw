const UserModel = require('./userModel');
const DmModel = require('./dmModel');
const setDmAuthority = async () => {


    userDetails = await UserModel.find();
    dmDetails = await DmModel.find();
    for (let i = 0; i <= userDetails.length - 1; i++)
    {

        for (let j = 0; j <= dmDetails.length - 1; j++)
        {

            for (let k = 0; k <= userDetails[i].managers.length - 1; k++)
            {
                if (userDetails[i].managers[k].email === dmDetails[j].username)
                {
                    console.log("DM present");
                    res = await UserModel.findOneAndUpdate(
                        { username: userDetails[i].username },
                        {
                            role: "DM"
                        }
                    );
                }
                else
                {
                    res = await UserModel.findOneAndUpdate(
                        { username: userDetails[i].username },
                        {
                            "managers.email": "Satyabaji.Sahu@harbingergroup.com"
                        }
                    );
                }

            }

        }

    }
}

module.exports = {
    setDmAuthority
}