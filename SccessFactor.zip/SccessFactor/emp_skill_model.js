const mongoose = require("mongoose");
var Schema = mongoose.Schema;

var EmployeeSkillMappingSchema = new Schema({
    username: {
        type: String,
      },
    skillname: {
        type: String
    },
    level: {
        type: String,
      },
      skillStatus: {
        type: String,
      },
      currentStatus: {
        type: String,
      },
      year: {
        type: Number,
        default:  2020,
      },
      experience: {
        type: String,

      },
      comment: {
        type: String,
      },
      createdDate: {
            type: Date,
        },
});

const EmpSkillsmapModel = mongoose.model("emp_skill_mappings", EmployeeSkillMappingSchema, "emp_skill_mappings");
module.exports = {EmpSkillsmapModel};
