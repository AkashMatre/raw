const axios = require('axios');
const UserModel = require('./userModel');


const getSuccessfactorData = async () => {

    const credentials = {
        UserName: "apiadmin@C0014228534T1",
        password: "SPD^dmin080"
    }

    let data = 'mis-prod:P@ssw0r!)#';
    let buff = new Buffer(data);
    let base64data = buff.toString('base64');
    var headers = {
        "Authorization": "Basic " + base64data
    }

    let res = await axios.get(
        'http://10.0.10.129:3000/successfactors/getEmpInfo',
        { headers: headers }
    );
    console.log(res, "res@@@@");
    const empResult = res && res.data && res.data.d && res.data.d.results;
    console.log(empResult.length, "result");
    for (let i = 0; i <= empResult.length - 1; i++)
    {

        console.log("record count", i)
        // // console.log(empResult[i]);
        console.log("Employee ID := " + empResult[i].userId);
        // console.log("Employee Name := " + empResult[i].defaultFullName);
        // console.log("Employee Designation := " + empResult[i].jobTitle);
        //console.log("Employee Email Address := " + empResult[i].email);
        // console.log("Managers:=" + empResult[i].manager.defaultFullName);
        // console.log("Managers Email:=" + empResult[i].manager.email);

        if (empResult[i].email !== "NA" && empResult[i].manager !== null && empResult[i].email !== undefined && empResult[i].userId !== undefined && empResult[i].email !== undefined)
        {
            console.log("Employee ID := " + empResult[i].userId);

            let emailSplit = empResult[i].manager.email.split("@")[0];
            const res = emailSplit.split(".");
            let newMail = ""
            if (emailSplit.includes("."))
            {
                const res = emailSplit.split(".");
                firstName = res[0].charAt(0).toUpperCase() + res[0].slice(1).toLowerCase();
                lastName = res[1].charAt(0).toUpperCase() + res[1].slice(1).toLowerCase();
                newMail = firstName + "." + lastName + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
            } else
            {
                firstName = emailSplit.charAt(0).toUpperCase() + emailSplit.slice(1) + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
                newMail = firstName;
            }

            let empupdtMail = ""
            let empemailSplit = empResult[i].email.split("@")[0];
            const empres = empemailSplit.split(".");
            let emplnewMail = ""
            if (empemailSplit.includes("."))
            {
                const empres = empemailSplit.split(".");
                firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
                lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
                empupdtMail = firstName + "." + lastName + "@" + empResult[i].email.split("@")[1].toLowerCase();
            } else
            {
                firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + empResult[i].email.split("@")[1].toLowerCase();
                empupdtMail = firstName;
            }
            try
            {
                const result = await UserModel.findOneAndUpdate({ username: empupdtMail },
                    {
                        "managers.email": newMail, empid: empResult[i].userId, fullname: empResult[i].defaultFullName,
                        designation: empResult[i].title, email: empupdtMail, department: empResult[i].department, location: empResult[i].location, companyName: empResult[i].department
                    });

            } catch (error)
            {
                console.log("Error Occured:- ", error);
            }


        }
        else
        {
            console.log("else Employee ID := " + empResult[i].userId, "@@@@@", [i]);
            // console.log("Employee Email Address := " + empResult[i].email);
            // console.log("Managers:=" + empResult[i].manager);
        }

    }
}
module.exports = {
    getSuccessfactorData
}