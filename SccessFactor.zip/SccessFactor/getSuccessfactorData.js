const axios = require('axios');
const UserModel = require('./userModel');
var fs = require('fs');

const getSuccessfactorData = async () => {
    console.log("In success factor data Updating")
    const credentials = {
        UserName: "apiadmin@C0014228534T1",
        password: "SPD^dmin080"
    }

    let data = 'mis-prod:P@ssw0r!)#';
    let buff = new Buffer(data);
    let base64data = buff.toString('base64');
    var headers = {
        "Authorization": "Basic " + base64data
    }
    let res = await axios.get(
        'http://10.0.10.129:3000/successfactors/getEmpInfo',
        { headers: headers }
    );
    let managers = [];
    const empResult = res && res.data && res.data.d && res.data.d.results;
    for (let i = 0; i <= empResult.length - 1; i++)
    {
        if (empResult[i].email !== "NA" && empResult[i].manager !== null && empResult[i].email !== undefined && empResult[i].userId !== undefined && empResult[i].manager !== undefined && empResult[i].email !== null)
        {
            let emailSplit = empResult[i].manager.email.split("@")[0];
            const res = emailSplit.split(".");
            let newMail = ""
            if (emailSplit.includes("."))
            {
                const res = emailSplit.split(".");
                firstName = res[0].charAt(0).toUpperCase() + res[0].slice(1).toLowerCase();
                lastName = res[1].charAt(0).toUpperCase() + res[1].slice(1).toLowerCase();
                newMail = firstName + "." + lastName + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
            } else
            {
                firstName = emailSplit.charAt(0).toUpperCase() + emailSplit.slice(1) + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
                newMail = firstName;
            }
            let empupdtMail = ""
            let empemailSplit = empResult[i].email.split("@")[0];
            const empres = empemailSplit.split(".");
            let emplnewMail = ""
            if (empemailSplit.includes("."))
            {
                const empres = empemailSplit.split(".");
                firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
                lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
                empupdtMail = firstName + "." + lastName + "@" + empResult[i].email.split("@")[1].toLowerCase();
            } else
            {
                firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + empResult[i].email.split("@")[1].toLowerCase();
                empupdtMail = firstName;
            }
            try
            {
               // managers.push({"name":empResult[i].manager.defaultFullName , "email":empResult[i].manager.email})
               managers.push(empResult[i].manager.defaultFullName)
                const result = await UserModel.findOneAndUpdate({ username: empupdtMail },
                    {
                        "managers.email": newMail, empid: empResult[i].userId, fullname: empResult[i].defaultFullName,
                        designation: empResult[i].title, email: empupdtMail, department: empResult[i].department, location: empResult[i].location, companyName: empResult[i].department
                    });
            } catch (error)
            {
                console.log("Error Occured:- ", error);
            }
        }
        else
        {
            if(empResult[i].email !== null && empResult[i].email !== "NA" && empResult[i].manager !== null && empResult[i].manager !== undefined)
             {
            let emailSplit = empResult[i].manager.email.split("@")[0];
            const res = emailSplit.split(".");
            let newMail = ""
            if (emailSplit.includes("."))
            {
                const res = emailSplit.split(".");
                firstName = res[0].charAt(0).toUpperCase() + res[0].slice(1).toLowerCase();
                lastName = res[1].charAt(0).toUpperCase() + res[1].slice(1).toLowerCase();
                newMail = firstName + "." + lastName + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
            } else
            {
                firstName = emailSplit.charAt(0).toUpperCase() + emailSplit.slice(1) + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
                newMail = firstName;
            }

            let empupdtMail = ""
            let empemailSplit = empResult[i].email.split("@")[0];
            const empres = empemailSplit.split(".");
            let emplnewMail = ""
            if (empemailSplit.includes("."))
            {
                const empres = empemailSplit.split(".");
                firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
                lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
                empupdtMail = firstName + "." + lastName + "@" + empResult[i].email.split("@")[1].toLowerCase();
            } else
            {
                firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + empResult[i].email.split("@")[1];
                empupdtMail = firstName;
            }
            managers.push(empResult[i].manager.defaultFullName)

            const result = await UserModel.findOneAndUpdate({ username: empupdtMail },
                {
                    "managers.email": newMail, empid: empResult[i].userId, fullname: empResult[i].defaultFullName,
                    designation: empResult[i].title, email: empupdtMail, department: empResult[i].department, location: empResult[i].location, companyName: empResult[i].department
                });
        }
        else{
        }
        }
        
    }
   // console.log(managers.filter((a, b) => managers.indexOf(a) === b))
    let newarray = managers.filter((a, b) => managers.indexOf(a) === b);
    let finalarray = "";

    newarray.map((newarray,key)=>{
       // console.log(finalarray ,"newarray")
        finalarray += newarray+'\r\n';
        //finalarray.push(newarray);
        // finalarray.push('\n')
        
    })

    fs.writeFile('DmAuthirisedEmployeeList.txt', finalarray, function(err) {
        // Deal with possible error here.
      });
}
module.exports = {
    getSuccessfactorData
}