const axios = require('axios');
const UserModel = require('./userModel');


const userValidation = async () => {

    const credentials = {
        UserName: "apiadmin@C0014228534T1",
        password: "SPD^dmin080"
    }
    let data = 'apiadmin@C0014228534T1:SPD^dmin080';
    let buff = new Buffer(data);
    let base64data = buff.toString('base64');
    var headers = {
        "Authorization": "Basic " + base64data
    }

    let res = await axios.get(
        'https://api10.successfactors.com/odata/v2/User?$format=json&$expand=manager&$select=userId,defaultFullName,jobTitle,email,manager/userId,manager/defaultFullName,manager/email',
        { headers: headers }
    );
    for (let i = 0; i <= res.data.d.results.length - 1; i++)
    {
        console.log(res.data.d.results[i].userId, "@@", res.data.d.results[i].email);
    }
}
module.exports = {
    userValidation
}