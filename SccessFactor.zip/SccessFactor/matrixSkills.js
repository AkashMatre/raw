const axios = require('axios');
const {EmpSkillsmapModel, SkillsMastermapModel} = require('./skillModel');
var request = require("request");

const getMatrixSkillsData = async () => {

    var matrixProjectDetailsURL =
        "https://matrix.harbinger-systems.com/readSkill.php"; 
  
        request(
            {
              rejectUnauthorized: false,
              url: matrixProjectDetailsURL
            },
            (err, res, body) => {
              if (err) {
                console.log(err);
                return;
              }
              JSON.parse(body).map((skills,index) =>{
                
                let empupdtMail = ""
                let empemailSplit =skills.mail.split("@")[0];
                const empres = empemailSplit.split(".");
                let emplnewMail = ""
                if (empemailSplit.includes("."))
                {
                    const empres = empemailSplit.split(".");
                    firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
                    lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
                    empupdtMail = firstName + "." + lastName + "@" + skills.mail.split("@")[1].toLowerCase();
                } else
                {
                    firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + skills.mail.split("@")[1].toLowerCase();
                    empupdtMail = firstName;
                }

               // console.log(skills.skill , index,"skills " , empupdtMail);

                if(skills.skill !== null || skills.skill !== "" || skills.skill !== undefined)
                {
                  const MatrixskillUpdate =  EmpSkillsmapModel.insertMany({ username: empupdtMail , skillname:skills.skill.toLowerCase() ,level:"Practitioner", });
                }
                else{
                  console.log(skills.skill , index,"skills else " , empupdtMail);
                }
               // const MatrixskillUpdate =  EmpSkillsmapModel.insertMany({ username: empupdtMail , skillname:"Java" ,level:"Practitioner", });
            })
            })

     

}
module.exports = {
    getMatrixSkillsData
}