const mongoose = require("mongoose");
var Schema = mongoose.Schema;
var SkillsSchema = new Schema({
    name: {
        type: String
    }
});

var EmployeeSkillMappingSchema = new Schema({
    skillname: {
        type: String
    }
});

const EmpSkillsmapModel = mongoose.model("emp_skill_mappings", EmployeeSkillMappingSchema, "emp_skill_mappings");
const SkillsMastermapModel = mongoose.model("skills", SkillsSchema, "skills");
module.exports = { SkillsMastermapModel,EmpSkillsmapModel};


// module.exports.SkillsMastermapModel = SkillsMastermapModel;
// module.exports.EmpSkillsmapModel = EmpSkillsmapModel;