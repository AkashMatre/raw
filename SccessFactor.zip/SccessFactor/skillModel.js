const mongoose = require("mongoose");
var Schema = mongoose.Schema;
var SkillsSchema = new Schema({
    name: {
        type: String
    }
});

var EmployeeSkillMappingSchema = new Schema({
    username: {
        type: String,
        required: true
      },
    skillname: {
        type: String
    },
    level: {
        type: String,
        required: true
      },
      skillStatus: {
        type: String,
        default: "approved",
        required: true
      },
      currentStatus: {
        type: String,
        default: "Practising",
        required: true
      },
      year: {
        type: Number,
        default:  2020,
      },
      experience: {
        type: String,
        default: "0 to 1 Yrs"
        // required: true
      },
      comment: {
        type: String,
        default: "-"
      },
      createdDate: {
            type: Date,
            default: Date.now
        },
});

const EmpSkillsmapModel = mongoose.model("emp_skill_mappings", EmployeeSkillMappingSchema, "emp_skill_mappings");
const SkillsMastermapModel = mongoose.model("skills", SkillsSchema, "skills");
module.exports = { SkillsMastermapModel,EmpSkillsmapModel};


// module.exports.SkillsMastermapModel = SkillsMastermapModel;
// module.exports.EmpSkillsmapModel = EmpSkillsmapModel;