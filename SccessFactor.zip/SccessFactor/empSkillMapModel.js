"use strict";
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const EmpSkillMapSchema = new Schema({
  username: {
    type: String,
    required: true
  },
  skillname: {
    type: String,
    required: true
  },
  level: {
    type: String,
    required: true
  },
  skillStatus: {
    type: String,
    default: "approved",
    required: true
  },
  currentStatus: {
    type: String,
    required: true
  },
  year: {
    type: Number
  },
  experience: {
    type: String,
    required: true
  },
  comment: {
    type: String,
  },
  createdDate: {
        type: Date,
        default: Date.now
    },
});

const SkillSchema = mongoose.model("emp_skill_mappings", EmpSkillMapSchema);

module.exports = SkillSchema;
