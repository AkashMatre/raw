const {EmpSkillsmapModel, SkillsMastermapModel} = require('./skillModel');

const skillMasterData = async () => {

    console.log("In Skill Master Updating")
    try {
        const skills = await EmpSkillsmapModel.find({},{skillname:1,_id:0});
        skills.map((skill)=>{
             SkillsMastermapModel.findOneAndUpdate({name:skill.skillname},{name:skill.skillname},{upsert: true}).exec(err => {
                 if(err){
                    console.error(err.message);
                    return err;
                 }
                 return;
             });
        })    
    } catch (error) {
        console.error(error);
        return error;
    }
}

module.exports = { skillMasterData }