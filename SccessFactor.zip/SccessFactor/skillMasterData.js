const {EmpSkillsmapModel, SkillsMastermapModel} = require('./skillModel');

const skillMasterData = async () => {

    console.log("In Skill Master Updating")
    try {
        const skills = await EmpSkillsmapModel.find({},{skillname:1,_id:0});
        skills.map((skill)=>{

            let updatedskill = skill.skillname.charAt(0).toUpperCase()+""+skill.skillname.slice(1)
             SkillsMastermapModel.findOneAndUpdate({name:updatedskill},{name:updatedskill},{upsert: true}).exec(err => {
                 if(err){
                    console.error(err.message);
                    return err;
                 }
                 return;
             });
        })    
    } catch (error) {
        console.error(error);
        return error;
    }
}

module.exports = { skillMasterData }