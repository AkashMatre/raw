
const varnodemailer = require("nodemailer");
 
exports.sendEmail = (fromEmail,toEmail,subject,body) => {
const vartransporter = varnodemailer.createTransport({
host: "mail01.harbingergroup.com",
port: 25,
service: "SMTP",
auth: {
    user: "akash.matre@harbingergroup.com",
    pass: "Matre2018"
    }
  });
 
    varmailOptions = {
    from:fromEmail,
    to:toEmail,
    subject:subject,
    text: body
  };

  vartransporter.sendMail(varmailOptions, function(error, info) {
    if (error) {
    console.log(error);
        } else {
    console.log("Email sent:" + info.response);
        }
    });
    };

