const UserModel = require('./userModel');
const DmModel = require('./dmModel');
const axios = require('axios');
const setImmedietDM = async () => {
    console.log("In set Immediate Dm ")
    let data = 'mis-prod:P@ssw0r!)#';
    let buff = new Buffer(data);
    let base64data = buff.toString('base64');
    var headers = {
        "Authorization": "Basic " + base64data
    }
    let res = await axios.get(
        'http://10.0.10.129:3000/successfactors/getEmpInfo',
        { headers: headers }
    );

    const empResult = res && res.data && res.data.d && res.data.d.results;
    for (let i = 0; i <= empResult.length - 1; i++)
    {
        if (empResult[i].email !== "NA" && empResult[i].manager !== null && empResult[i].email !== undefined && empResult[i].userId !== undefined  && empResult[i].manager !== undefined && empResult[i].email !== null)
        {
            let empupdtMail = ""
            let empemailSplit = empResult[i].email.split("@")[0];
            const empres = empemailSplit.split(".");
            let emplnewMail = ""
            if (empemailSplit.includes("."))
            {
                const empres = empemailSplit.split(".");
                firstName = empres[0].charAt(0).toUpperCase() + empres[0].slice(1).toLowerCase();
                lastName = empres[1].charAt(0).toUpperCase() + empres[1].slice(1).toLowerCase();
                empupdtMail = firstName + "." + lastName + "@" + empResult[i].email.split("@")[1].toLowerCase();
            } else
            {
                firstName = empemailSplit.charAt(0).toUpperCase() + empemailSplit.slice(1) + "@" + empResult[i].email.split("@")[1].toLowerCase();
                empupdtMail = firstName;
            }
            let manageremailSplit = empResult[i].manager.email.split("@")[0];
            const res = manageremailSplit.split(".");
            let newMail = ""
            if (manageremailSplit.includes("."))
            {
                const res = manageremailSplit.split(".");
                firstName = res[0].charAt(0).toUpperCase() + res[0].slice(1).toLowerCase();
                lastName = res[1].charAt(0).toUpperCase() + res[1].slice(1).toLowerCase();
                newMail = firstName + "." + lastName + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
            } else
            {
                firstName = manageremailSplit.charAt(0).toUpperCase() + manageremailSplit.slice(1) + "@" + empResult[i].manager.email.split("@")[1].toLowerCase();
                newMail = firstName;
            }
            dmDetails = await DmModel.findOne({ username: empupdtMail });

            if (dmDetails !== null)
            {
                updateDm = await UserModel.findOneAndUpdate({ username: empupdtMail }, { role: "DM" });

            }
        }
    }
}

module.exports = {
    setImmedietDM
}