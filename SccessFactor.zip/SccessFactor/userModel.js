const mongoose = require("mongoose");
var Schema = mongoose.Schema;
var UserSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    passwords: {
        type: [String],
        default: undefined
    },
    firstname: {
        type: String,
        required: true
    },
    lastname: {
        type: String
    },
    role: { type: String, default: "Employee" },
    managers: {
        type: [],
        default: undefined
    },
    empid: {
        type: String,
    },
    fullname: {
        type: String,
    },
    designation: {
        type: String,
    },
    email: {
        type: String,
    }
});
const UserModel = mongoose.model("users", UserSchema);
module.exports = UserModel;
